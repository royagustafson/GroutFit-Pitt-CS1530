CREATE FUNCTION st_asbinary(geography, text)
  RETURNS bytea
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_AsBinary($1::public.geometry, $2);
$$;

