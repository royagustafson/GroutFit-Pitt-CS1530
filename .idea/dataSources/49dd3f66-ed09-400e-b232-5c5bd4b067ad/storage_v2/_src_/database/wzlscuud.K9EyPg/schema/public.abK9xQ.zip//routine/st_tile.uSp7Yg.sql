CREATE FUNCTION st_tile(rast raster, width integer, height integer, padwithnodata boolean DEFAULT false, nodataval double precision DEFAULT NULL::double precision)
  RETURNS SETOF raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_tile($1, $2, $3, NULL::integer[], $4, $5)
$$;

