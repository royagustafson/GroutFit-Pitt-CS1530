CREATE FUNCTION st_approxhistogram(rast raster, nband integer, exclude_nodata_value boolean, sample_percent double precision, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision)
  RETURNS SETOF record
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT min, max, count, percent FROM public._ST_histogram($1, $2, $3, $4, $5, NULL, $6)
$$;

