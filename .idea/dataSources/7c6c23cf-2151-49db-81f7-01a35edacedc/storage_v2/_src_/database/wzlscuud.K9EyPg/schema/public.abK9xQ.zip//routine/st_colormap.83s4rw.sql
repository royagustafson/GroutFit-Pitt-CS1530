CREATE FUNCTION st_colormap(rast raster, colormap text, method text DEFAULT 'INTERPOLATE'::text)
  RETURNS raster
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_ColorMap($1, 1, $2, $3)
$$;

