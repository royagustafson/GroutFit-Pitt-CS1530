CREATE FUNCTION st_force_3d(geometry)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Force_3d', 'ST_Force3D', '2.1.0');
    SELECT public.ST_Force3D($1);
$$;

