CREATE FUNCTION st_length_spheroid(geometry, spheroid)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Length_Spheroid', 'ST_LengthSpheroid', '2.2.0');
    SELECT public.ST_LengthSpheroid($1,$2);
$$;

