CREATE FUNCTION st_pixelofvalue(rast raster, nband integer, search double precision, exclude_nodata_value boolean DEFAULT true, OUT x integer, OUT y integer)
  RETURNS SETOF record
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT x, y FROM public.ST_PixelofValue($1, $2, ARRAY[$3], $4)
$$;

