CREATE FUNCTION st_approxquantile(rast raster, exclude_nodata_value boolean, quantile double precision DEFAULT NULL::double precision)
  RETURNS double precision
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT ( public._ST_quantile($1, 1, $2, 0.1, ARRAY[$3]::double precision[])).value
$$;

