CREATE FUNCTION xpath_nodeset(text, text, text)
  RETURNS text
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT xpath_nodeset($1,$2,'',$3)
$$;

