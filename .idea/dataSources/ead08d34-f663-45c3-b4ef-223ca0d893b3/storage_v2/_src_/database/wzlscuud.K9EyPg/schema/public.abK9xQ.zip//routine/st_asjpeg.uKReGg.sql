CREATE FUNCTION st_asjpeg(rast raster, nband integer, quality integer)
  RETURNS bytea
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.st_asjpeg($1, ARRAY[$2], $3)
$$;

