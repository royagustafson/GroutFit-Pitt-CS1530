CREATE FUNCTION st_area(text)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT ST_Area($1::public.geometry);
$$;

