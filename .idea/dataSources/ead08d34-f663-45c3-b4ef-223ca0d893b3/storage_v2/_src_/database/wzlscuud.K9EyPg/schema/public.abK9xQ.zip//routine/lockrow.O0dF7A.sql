CREATE FUNCTION lockrow(text, text, text)
  RETURNS integer
STRICT
LANGUAGE SQL
AS $$
SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00');
$$;

