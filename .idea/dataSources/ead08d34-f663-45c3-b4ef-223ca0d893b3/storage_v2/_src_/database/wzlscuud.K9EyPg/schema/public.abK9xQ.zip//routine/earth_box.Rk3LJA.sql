CREATE FUNCTION earth_box(earth, double precision)
  RETURNS cube
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT cube_enlarge($1, gc_to_sec($2), 3)
$$;

