CREATE FUNCTION st_asgml(version integer, geog geography, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0, nprefix text DEFAULT NULL::text, id text DEFAULT NULL::text)
  RETURNS text
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_AsGML($1, $2, $3, $4, $5, $6);
$$;

