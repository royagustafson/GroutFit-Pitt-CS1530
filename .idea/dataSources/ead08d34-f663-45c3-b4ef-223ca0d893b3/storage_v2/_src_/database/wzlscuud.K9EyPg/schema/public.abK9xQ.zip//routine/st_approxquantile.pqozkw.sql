CREATE FUNCTION st_approxquantile(rastertable text, rastercolumn text, nband integer, sample_percent double precision, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision)
  RETURNS SETOF record
STABLE
LANGUAGE SQL
AS $$
SELECT public._ST_quantile($1, $2, $3, TRUE, $4, $5)
$$;

